<div class="row">
    <div class="col-sm-12 col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Selamat datang!</h3>
            </div>
        </div>
    </div>
</div>