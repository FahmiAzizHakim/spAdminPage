<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
  function __construct() {
    parent::__construct();
  }

  public function index()
  {
    if($this->session->userdata('id_user') <> '') {
      redirect('home');
    }
    
    $d['page'] = 'login';
    $d['title'] = 'Login';
    $this->load->view('layout', $d);
  }

  function reset_password()
  {
    $d['page'] = 'reset_password';
    $this->load->view('layout', $d);
  }

  function register()
  {
    $d['page'] = 'register';
    $this->load->view('layout', $d);
  }
  
  function cek_user()
  {
    $username = $this->input->post('username');
    $passwords = $this->input->post('password');
    $password = sha1($passwords);

    $cek = $this->m_auth->cek_user($username, $password)->num_rows();
    $get = $this->m_auth->cek_user($username, $password)->result();

    if($cek == 1){
      foreach($get as $sess){
        $sess_data['id_user'] = $sess->id_user;
        $sess_data['id_role'] = $sess->id_role;
        $sess_data['nama'] = $sess->nama;
        $sess_data['motto'] = $sess->motto;
        $sess_data['user'] = $sess->user;
        $this->session->set_userdata($sess_data);
      }

      echo json_encode(array(
        'cek' => '1'
        ));
    }else{
      echo json_encode(array(
        'cek' => '0'
        ));
    }
  }

  function logout()
  {
    $this->session->sess_destroy();
    redirect('/');
  }
}
